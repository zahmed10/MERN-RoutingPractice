import React from 'react'

const Home = (props) => {
    return (
        <h1 style={{color: "red"}}>Welcome!</h1>
    );
}

export default Home
